// Umple was used a guide and generated some code in this project
package ca.mcgill.ecse321.Mar1HotelSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mar1HotelSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(Mar1HotelSystemApplication.class, args);
	}

    public Object getStatus() {
        return null;
    }

    public Object getMessage() {
        return null;
    }

}
