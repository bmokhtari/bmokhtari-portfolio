package ca.mcgill.ecse321.Mar1HotelSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mar1HotelSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
