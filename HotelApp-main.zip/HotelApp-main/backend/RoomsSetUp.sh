#!/bin/bash

curl -X POST -H "Content-Type: application/json" -d@Rooms.json http://localhost:8080/rooms