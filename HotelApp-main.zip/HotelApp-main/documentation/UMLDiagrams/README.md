# UML Diagrams

Please put all diagrams in image format (PNG, JPG, SVG) in this directory.