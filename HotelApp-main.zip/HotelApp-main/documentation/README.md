# Documentation

This directory contains UML diagrams (PlantUML code), Umple code, and other documentation for the project.

## UML Diagrams
- Domain Model
- Use Case Diagrams
- Sequence Diagrams (?)

## Umple Code
- Domain Model
- State Machine (?)
