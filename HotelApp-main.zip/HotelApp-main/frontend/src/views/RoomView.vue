<script setup lang="ts">
</script>

<template>
    <main>
        Hello
    </main>
</template>

<style scoped>
</style>